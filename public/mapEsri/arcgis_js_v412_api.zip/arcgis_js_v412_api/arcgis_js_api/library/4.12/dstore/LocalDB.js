//>>built
define(["./db/has!indexeddb?./db/IndexedDB:sql?./db/SQL:./db/LocalStorage"],function(a){return a});
//>>built
define(["./has"],function(a){return JSON});
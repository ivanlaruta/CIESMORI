//>>built
define(["./router/RouterBase"],function(a){return new a({})});
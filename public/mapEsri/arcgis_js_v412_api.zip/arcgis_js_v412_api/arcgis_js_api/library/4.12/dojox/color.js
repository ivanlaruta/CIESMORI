//>>built
define(["./color/_base"],function(a){return a});
//>>built
define(["./storage/_common"],function(){});
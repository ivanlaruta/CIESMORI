//>>built
define(["./collections/_base"],function(a){return a});